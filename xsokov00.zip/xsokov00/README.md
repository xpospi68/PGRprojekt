PGRprojekt
==========

Projekt do predmetu PGR 2014/2015: Jednoklávesová hra s použitím OpenGL "﻿g-switch"

Autori:
Veronika Šoková <xsokov00@stud.fit.vutbr.cz>
Tereza Honzátková <xhonza01@stud.fit.vutbr.cz>
Petr Pospíšil <xpospi68@stud.fit.vutbr.cz>

Závislosti:
	• OpenGL
	• SDL
	• GLee (linux) / Glew (win)
	• GLM

Tereza:
> textúry (hráč, steny, pozadie), vykreslovanie textu

Petr:
> generovanie scény, návrh levelov


Veronika:
> logika hráča (detekcia kolízí), prepojenie levelov

